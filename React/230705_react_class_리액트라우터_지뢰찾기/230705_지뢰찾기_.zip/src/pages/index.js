
import Modal from "./Modal"
import Main from "./Main"

export {Modal , Main}