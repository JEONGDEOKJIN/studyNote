import imgBomb from "./bomb_png.png"
import imgHappy from "./happy.gif"

export {imgBomb , imgHappy}