import './App.css';

import { TodoBoard }  from './components'
import { useState } from 'react'



function App() {

  return (
    <div className="App">

      <TodoBoard  />

    </div>
  );
}

export default App;
