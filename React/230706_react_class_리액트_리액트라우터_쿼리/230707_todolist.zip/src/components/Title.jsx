


import React from 'react'

const Title = () => {
  return (
    <div>
        <div className='title_container' >
            <div className='title_no titleDeco ' > No  </div>
            <div className='title_check titleDeco' > ✅  </div>
            <div className='title_list titleDeco' > 할일 </div>
        </div>
    </div>
  )
}


export default Title