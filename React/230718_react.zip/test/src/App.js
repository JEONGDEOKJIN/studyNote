import './App.css';
import Context from './context/Context';
import Reducer from './reducer/Reducer';
import Memo from './Memo/Memo';

function App() {
  return (
    <>
      <div className="App">
      
      are you hi? who are you. it's rainny day. hahaha hoo <br>
      </br>
      
      {/* <Context>  </Context> */}
      
        {/* <Reducer> </Reducer> */}


        {/* <Callback> </Callback> */}

        <Memo> </Memo>

      </div>
    
    </>
  );
}

export default App;
